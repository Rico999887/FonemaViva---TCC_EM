Tchau painho
