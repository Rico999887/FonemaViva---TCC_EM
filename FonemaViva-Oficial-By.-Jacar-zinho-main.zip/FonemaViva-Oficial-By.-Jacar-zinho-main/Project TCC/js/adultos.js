const supabaseUrl =

"https://mnfryxvtogpiwacpyhgo.supabase.co";

const supabaseKey =

"sb_publishable_YYMfDfWKaer8F1IEOFVOMQ_acS2xa2G";

const supabaseClient =

window.supabase.createClient(

  supabaseUrl,

  supabaseKey

);

// ==========================
// PROTEÇÃO DE SESSÃO
// ==========================

function verificarSessao() {

  const usuarioId =

  localStorage.getItem("usuarioId") ||

  sessionStorage.getItem("usuarioId");

  if (!usuarioId) {

    window.location.replace(

      "./index.html"

    );

  }

}

verificarSessao();

window.addEventListener(

  "pageshow",

  verificarSessao

);

// ==========================
// ATUALIZA PERFIL PELO SUPABASE
// ==========================

async function atualizarPerfilUsuario() {

  try {

    const usuarioId =

    localStorage.getItem("usuarioId") ||

    sessionStorage.getItem("usuarioId");

    if (!usuarioId) return;

    const { data, error } =

    await supabaseClient

    .from("usuarios")

    .select("*")

    .eq("id", usuarioId)

    .single();

    if (error) {

      console.error(error);

      return;

    }

    const nomeElemento =

    document.getElementById(

      "user-name"

    );

    const fotoElemento =

    document.getElementById(

      "user-photo"

    );

    if (nomeElemento) {

      nomeElemento.textContent =

      data.apelido ||

      data.nome ||

      "Usuário";

    }

    if (

      fotoElemento &&

      data.foto_perfil

    ) {

      fotoElemento.src =

      data.foto_perfil;

    }

  }

  catch (erro) {

    console.error(

      "Erro ao carregar perfil:",

      erro

    );

  }

}

atualizarPerfilUsuario();

// MENU LATERAL

const menuToggle =

document.querySelector(

  ".menu-toggle"

);

const sideMenu =

document.querySelector(

  ".side-menu"

);

const closeMenu =

document.querySelector(

  ".close-menu"

);

const overlay =

document.querySelector(

  ".menu-overlay"

);

// BOTÃO DE ABRIR MENU

if(menuToggle && sideMenu && overlay){

  menuToggle.addEventListener(

    "click",

    ()=>{

      sideMenu.classList.add(

        "active"

      );

      overlay.classList.add(

        "active"

      );

    }

  );

}

// BOTÃO DE FECHAR MENU

if(closeMenu){

  closeMenu.addEventListener(

    "click",

    closeSideMenu

  );

}

if(overlay){

  overlay.addEventListener(

    "click",

    closeSideMenu

  );

}

function closeSideMenu(){

  if(sideMenu){

    sideMenu.classList.remove(

      "active"

    );

  }

  if(overlay){

    overlay.classList.remove(

      "active"

    );

  }

}

// ==========================
// LOGOUT
// ==========================

const logoutBtn =

document.getElementById(

  "logoutBtn"

);

const logoutModal =

document.querySelector(

  ".logout-modal"

);

const cancelLogout =

document.getElementById(

  "cancelLogout"

);

const confirmLogout =

document.getElementById(

  "confirmLogout"

);

const logoutLoading =

document.querySelector(

  ".logout-loading"

);

// ==========================
// EVENTOS DO LOGOUT
// ==========================

if(logoutBtn){

  logoutBtn.addEventListener(

    "click",

    () => {

      if(logoutModal){

        logoutModal.classList.add(

          "active"

        );

      }

    }

  );

}

if(cancelLogout){

  cancelLogout.addEventListener(

    "click",

    () => {

      if(logoutModal){

        logoutModal.classList.remove(

          "active"

        );

      }

    }

  );

}

if(confirmLogout){

  confirmLogout.addEventListener(

    "click",

    () => {

      if(logoutModal){

        logoutModal.classList.remove(

          "active"

        );

      }

      if(logoutLoading){

        logoutLoading.classList.add(

          "active"

        );

      }

      localStorage.clear();

      sessionStorage.clear();

      setTimeout(

        () => {

          location.replace(

            "./index.html"

          );

        },

        1500

      );

    }

  );

}

// FILTRA AS CATEGORIAS

const menuItems =

document.querySelectorAll(

  "#menu li"

);

const cards =

document.querySelectorAll(

  ".card"

);

menuItems.forEach(item=>{

  item.addEventListener(

    "click",

    ()=>{

      menuItems.forEach(i=>{

        i.classList.remove(

          "active"

        );

      });

      item.classList.add(

        "active"

      );

      const categoria =

      item.dataset.cat;

      cards.forEach(card=>{

        if(

          categoria === "todos" ||

          card.dataset.cat === categoria

        ){

          card.style.display =

          "block";

        } else {

          card.style.display =

          "none";

        }

      });

    }

  );

});

// CONTADOR DE PROGRESSO

let progress = {

  respiracao: 0,

  pronuncia: 0,

  audicao: 0,

  coordenacao: 0

};

// ATUALIZA

function updateUI(){

// RESPIRAÇÃO

const respiracao =

Number(

  localStorage.getItem("respiracao-progress")

) || 0;

const sopro =

Number(

  localStorage.getItem("sopro-progress")

) || 0;

progress.respiracao =

Math.round(

  (respiracao + sopro) / 2

);

// PRONÚNCIA

const sonsRL =

Number(

  localStorage.getItem("sons-rl-progress")

) || 0;

const leitura =

Number(

  localStorage.getItem("leitura-progress")

) || 0;

const travaLingua =

Number(

  localStorage.getItem("travalingua-progress")

) || 0;

const diccao =

Number(

  localStorage.getItem("diccao-progress")

) || 0;

progress.pronuncia =

Math.round(

  (sonsRL + leitura + travaLingua + diccao) / 4

);

// AUDIÇÃO

const escuta =

Number(

  localStorage.getItem("escuta-progress")

) || 0;

const diferenciacao =

Number(

  localStorage.getItem("diferenciacao-progress")

) || 0;

const desafioAuditivo =

Number(

  localStorage.getItem("desafio-auditivo-progress")

) || 0;

progress.audicao =

Math.round(

  (escuta + diferenciacao + desafioAuditivo) / 3

);

// COORDENAÇÃO

const movimentos =

Number(

  localStorage.getItem("movimentos-lingua-progress")

) || 0;

const sequencia =

Number(

  localStorage.getItem("sequencia-palavras-progress")

) || 0;

progress.coordenacao =

Math.round(

  (movimentos + sequencia) / 2

);

// BARRA DE PROGRESSO DE CADA CATEGORIA

document.getElementById(

  "p-respiracao"

).innerText =

progress.respiracao + "%";

document.getElementById(

  "p-pronuncia"

).innerText =

progress.pronuncia + "%";

document.getElementById(

  "p-audicao"

).innerText =

progress.audicao + "%";

document.getElementById(

  "p-coordenacao"

).innerText =

progress.coordenacao + "%";

// BARRAS DE PROGRESSO

document.getElementById(

  "b-respiracao"

).style.width =

progress.respiracao + "%";

document.getElementById(

  "b-pronuncia"

).style.width =

progress.pronuncia + "%";

document.getElementById(

  "b-audicao"

).style.width =

progress.audicao + "%";

document.getElementById(

  "b-coordenacao"

).style.width =

progress.coordenacao + "%";

// TOTAL DO PROGRESSO GERAL

// TOTAL GERAL

const total =

Math.round(

  (

    progress.respiracao +

    progress.pronuncia +

    progress.audicao +

    progress.coordenacao

  ) / 4

);

  const pTotal =

  document.getElementById(

  "p-total"

  );

  if(pTotal){

  pTotal.innerText =

  total + "%";

}

}

// INICIA OS EXERCÍCIOS

cards.forEach(card=>{

  const button =

  card.querySelector(

    ".iniciar"

  );

  if(button){

    button.addEventListener(

      "click",

      ()=>{

        // REDIRECIONA

        window.location.href =

        button.dataset.link;

      }

    );

  }

});

// INICIA

updateUI();

window.addEventListener(

    "focus",

    updateUI

);

window.addEventListener(

    "pageshow",

    updateUI

);

window.addEventListener(

    "progressoAtualizado",

    updateUI

);

// ==========================
// CARREGAMENTO INICIAL
// ==========================

window.addEventListener(

  "load",

  () => {

    const pageLoading =

    document.getElementById(

      "pageLoading"

    );

    if (!pageLoading) return;

    setTimeout(

      () => {

        pageLoading.classList.add(

          "loaded"

        );

        setTimeout(

          () => {

            pageLoading.remove();

          },

          550

        );

      },

      900

    );

  }

);